import java.io.*;
/**
 * <p>Title: �֏:��</p>
 * <p>Description: :(RandomAccessFile{�և�</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Filename: RandFile.java</p>
 * @author \_
 * @version 1.0
 */
public class RandFile{
/**
 *<br>���;��
 *<br>�e�p
 *<br>��{�
 */
  public static void main(String[] args){
    String sFile;
    if(args.length<1){
      System.out.println("USE:java RandFile fileName");
      return;
    }else{
      sFile = args[0];
    }
    //��IOException8
    try{
      //� �:���(����
      RandomAccessFile rf = new  RandomAccessFile(sFile, "rw");
      for(int i = 0; i < 10; i++)
      	rf.writeDouble(i*1.414);
      rf.close();
      //�  *�:���(���
      rf = new RandomAccessFile(sFile, "rw");
      rf.seek(5*8);
      rf.writeDouble(47.0001);
      rf.close();
      //�  *�:�����(���
      rf = new RandomAccessFile(sFile, "r");
      for(int i = 0; i < 10; i++)
       	System.out.println("Value " + i + ": " + rf.readDouble());
      rf.close();
     }catch(IOException e){
       System.out.println(e);
     }
  }
}
