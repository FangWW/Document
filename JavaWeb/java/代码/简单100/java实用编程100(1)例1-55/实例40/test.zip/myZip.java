//��myZip.java
import java.io.*;
import java.util.*;
import java.util.zip.*;
/**
 * <p>Title: ���)��</p>
 * <p>Description: (ZipInputStream�ZipOutputStream���
 *                 ��U�L�)��</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Filename: </p>
 * @author \_
 * @version 1.0
 */
public class myZip{
/**
 *<br>���������)
 *<br>�e�pString[] fs �)���p�
 *<br>��{�
 */
  public void ZipFiles(String[] fs){
   try{
     String fileName = fs[0];
     FileOutputStream f =
       new FileOutputStream(fileName+".zip");
     //(��A��
     CheckedOutputStream cs = 
        new CheckedOutputStream(f,new Adler32());
      //���zipA
      ZipOutputStream out =
        new ZipOutputStream(new BufferedOutputStream(cs));
      //� *��
      out.setComment("A test of Java Zipping");
      //����L�)
      for(int i=1;i<fs.length;i++){
        System.out.println("Write file "+fs[i]);
        BufferedReader in =
           new BufferedReader(
             new FileReader(fs[i]));
         out.putNextEntry(new ZipEntry(fs[i]));
         int c;
         while((c=in.read())!=-1)
          out.write(c);
        in.close();
       }
       //s��A
       out.close();
       System.out.println("Checksum::"+cs.getChecksum().getValue());
    }catch(Exception e){
       System.err.println(e);
    }
  }

/**
 *<br>����)Zip��
 *<br>�e�pString fileName �zip��
 *<br>��{�
 */
  public void unZipFile(String fileName){
    try{
       System.out.println("��ZIP��........");
       //���eA
       FileInputStream fi =
         new FileInputStream(fileName+".zip");
       //�eA��
       CheckedInputStream csi = new CheckedInputStream(fi,new Adler32());
       //�eA�)
       ZipInputStream in2 =
         new ZipInputStream(
           new BufferedInputStream(csi));
       ZipEntry ze;
       System.out.println("Checksum::"+csi.getChecksum().getValue());
       //�h��
       while((ze = in2.getNextEntry())!=null){
         System.out.println("Reading file "+ze);
         int x;
         while((x= in2.read())!=-1)
           //��/���write/�byte���
           System.out.write(x);
       }
       in2.close();
    }catch(Exception e){
      System.err.println(e);
    }
  }
/**
 *<br>�����Zip��h
 *<br>�e�pString fileName zip��
 *<br>��{�Vector ��h
 */
  public Vector listFile(String fileName){
    try{
       String[] aRst=null;
       Vector vTemp = new Vector();
       //zip���a
       ZipFile zf = new ZipFile(fileName+".zip");
       Enumeration e = zf.entries();
       while(e.hasMoreElements()){
         ZipEntry ze2 = (ZipEntry)e.nextElement();
         System.out.println("File: "+ze2);
         vTemp.addElement(ze2);
       }
       return  vTemp;
    }catch(Exception e){
      System.err.println(e);
      return null;
    }
  }
/**
 *<br>���;��
 *<br>�e�p
 *<br>��{�
 */
  public static void main(String[] args){
    try{
     String fileName = args[0];
     myZip myZip = new myZip();
     myZip.ZipFiles(args);
     myZip.unZipFile(fileName);
     Vector dd = myZip.listFile(fileName);
     System.out.println("File List: "+dd);
    }catch(Exception e){
    	e.printStackTrace();
    }
  }
}
