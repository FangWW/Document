package com.javapatterns.dip;

public class Checking extends AccountType
{
    public void deposit(float amt)
    {
        //write your code here
    }
}
