package com.javapatterns.dip;

public class Savings extends AccountType
{
    public void deposit(float amt)
    {
        //write your code here
    }
}
