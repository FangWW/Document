package com.javapatterns.dip;

abstract public class AccountType
{
    public abstract void deposit(float amt);
}
