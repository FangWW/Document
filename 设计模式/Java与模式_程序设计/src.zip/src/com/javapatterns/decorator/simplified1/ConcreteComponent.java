package com.javapatterns.decorator.simplified1;

public class ConcreteComponent {
    public ConcreteComponent() {
    }

    public void sampleOperation(){
        // Write your code here
    }
}
