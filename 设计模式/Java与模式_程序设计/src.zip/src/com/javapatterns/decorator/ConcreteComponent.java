package com.javapatterns.decorator;

public class ConcreteComponent implements Component
{
    public void sampleOperation()
    {
        // Write your code here
    }
}
