package com.javapatterns.builder.simplified1;

public class ConcreteBuilder
{
    /**
     * @directed 
     */
    private Product product = new Product();

    public void buildPart1()
    {
        // Write your code here
    }

    public void buildPart2()
    {
        // Write your code here
    }

    public Product getResult()
    {
        return product;
    }
}
