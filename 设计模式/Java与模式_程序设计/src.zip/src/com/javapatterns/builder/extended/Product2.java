package com.javapatterns.builder.extended;

public class Product2 implements Product
{
    public Product2()
    {
        //Write your code here
    }
}
