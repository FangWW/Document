package com.javapatterns.builder.rtfreader;

public class ASCIIText
{
    public void append(char c)
	{ //Implement the code here
	}
}
