package com.javapatterns.builder.simplified2;

public class Product
{
    public Product()
    {
        //default constructor
    }
}
