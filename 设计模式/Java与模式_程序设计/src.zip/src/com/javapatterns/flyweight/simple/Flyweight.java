package com.javapatterns.flyweight.simple;

abstract public class Flyweight
{
    abstract public void operation(String state);
}
