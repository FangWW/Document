package com.javapatterns.abstractfactory.farm;

public interface Veggie
{
}
