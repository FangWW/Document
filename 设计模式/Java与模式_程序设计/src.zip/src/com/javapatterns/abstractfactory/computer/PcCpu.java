package com.javapatterns.abstractfactory.computer;

public class PcCpu implements Cpu
{
}
