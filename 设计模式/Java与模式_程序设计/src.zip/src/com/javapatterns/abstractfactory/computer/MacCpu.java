package com.javapatterns.abstractfactory.computer;

public class MacCpu implements Cpu
{
}
