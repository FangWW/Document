package com.javapatterns.abstractfactory.computer;

public class PcRam implements Ram
{
}
