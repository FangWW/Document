package com.javapatterns.abstractfactory.computer;

public class MacRam implements Ram
{
}
