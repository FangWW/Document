package com.javapatterns.abstractfactory;

public interface ProductB
{
}
