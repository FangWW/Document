package com.javapatterns.abstractfactory.exercise3;

public interface Ram
{
}
