package com.javapatterns.abstractfactory.exercise3;

public class PcRam implements Ram
{
}
