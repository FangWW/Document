package com.javapatterns.abstractfactory.exercise3;

public class MacCpu implements Cpu
{
}
