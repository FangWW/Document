package com.javapatterns.abstractfactory.exercise1;

public class PcRam implements Ram
{
}
