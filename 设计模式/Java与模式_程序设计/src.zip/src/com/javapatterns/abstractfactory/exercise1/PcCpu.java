package com.javapatterns.abstractfactory.exercise1;

public class PcCpu implements Cpu
{
}
