package com.javapatterns.bridge;

public class ConcreteImplementorB extends Implementor
{
    public void operationImp()
    {
        System.out.println("Do something...");
    }
}
