package com.javapatterns.bridge;

public class ConcreteImplementorA extends Implementor
{
    public void operationImp()
    {
        System.out.println("Do something...");
    }
}
