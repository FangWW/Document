
package com.javapatterns.bridge.airplanes2;

abstract public class AirplaneMaker
{
	abstract public void produce();
}
