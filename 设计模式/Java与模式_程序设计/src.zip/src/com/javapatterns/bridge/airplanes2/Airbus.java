
package com.javapatterns.bridge.airplanes2;

public class Airbus extends AirplaneMaker
{
	public void produce()
    {
		//Write your code here
    }
}
