package com.javapatterns.bridge;

public class RefinedAbstraction extends Abstraction
{
    public void operation()
    {
     	// improved logic
    }
}
