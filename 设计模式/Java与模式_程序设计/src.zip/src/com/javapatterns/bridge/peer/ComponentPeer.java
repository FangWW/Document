package com.javapatterns.bridge.peer;

abstract public class ComponentPeer {
}
