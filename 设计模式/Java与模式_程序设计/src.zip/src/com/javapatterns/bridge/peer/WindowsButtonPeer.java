package com.javapatterns.bridge.peer;


public class WindowsButtonPeer extends ButtonPeer {
}
