package com.javapatterns.bridge.peer;

abstract public class Component {
    /**
     * @link aggregation
     * @directed
     */
    private ComponentPeer lnkComponentPeer;
}
