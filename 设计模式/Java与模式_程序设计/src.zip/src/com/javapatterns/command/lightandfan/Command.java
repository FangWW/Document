package com.javapatterns.command.lightandfan;

public interface Command {
        public abstract void execute ( );
}

