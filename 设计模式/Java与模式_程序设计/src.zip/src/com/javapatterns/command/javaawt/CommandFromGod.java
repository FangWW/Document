package com.javapatterns.command.javaawt;

public interface CommandFromGod
{
   public void Execute();
}
