package com.javapatterns.facade;

public class LineOutput
{ 

	public LineOutput()
	{
	}
	
	public void singleLine()
	{ 
	
		System.out.println("------------------------------");
	
	}
	
	public void doubleLine()
	{ 
	
		System.out.println("=============================="); 
	
	} 

}


