package com.javapatterns.isp.altavista;

public interface Indexer
{
    void reIndexAll();

    void updateIndex();
}
