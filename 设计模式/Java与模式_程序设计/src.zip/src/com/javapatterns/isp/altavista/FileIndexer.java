package com.javapatterns.isp.altavista;

public class FileIndexer implements Indexer
{
    public void reIndexAll()
    {
    	//write your code here
    }

    public void updateIndex()
    {
    	//write your code here
    }
}
