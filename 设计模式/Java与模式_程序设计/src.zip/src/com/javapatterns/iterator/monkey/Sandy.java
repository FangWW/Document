package com.javapatterns.iterator.monkey;

public class Sandy extends Desciple
{
    public void speak()
    {
		System.out.println("I am Sandy");
    }
}
