package com.javapatterns.iterator.monkey;

public class Monkey extends Desciple
{
    public void speak()
    {
		System.out.println("I am Monkey");
    }
}
