package com.javapatterns.adapter.kittie2puppie;

public class Kittie {
    public void miao(){}

    public void catchRat() {
    }

    public void run() {
    }

    public void sleep() {
    }

    public String getName(){ return name; }

    public void setName(String name){ this.name = name; }

    private String name;
}
