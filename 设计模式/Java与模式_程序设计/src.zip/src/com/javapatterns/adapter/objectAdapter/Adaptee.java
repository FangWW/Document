package com.javapatterns.adapter.objectAdapter;

public class Adaptee {
    public void sampleOperation1(){}
}
