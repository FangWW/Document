package com.javapatterns.composite.drawingsafe;

abstract public class Graphics
{
    public abstract void draw();
}

