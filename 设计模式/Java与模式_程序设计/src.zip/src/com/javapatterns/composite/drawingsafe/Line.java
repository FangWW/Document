package com.javapatterns.composite.drawingsafe;

public class Line extends Graphics 
{
    public void draw()
    {
        //write your code here
    }
}

