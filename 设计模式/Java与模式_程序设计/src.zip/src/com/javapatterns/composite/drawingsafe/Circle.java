package com.javapatterns.composite.drawingsafe;

public class Circle extends Graphics 
{
    public void draw()
    {
        //write your code here
    }
}

