package com.javapatterns.composite.drawingtransparent;

public class Circle extends Graphics 
{
    public void draw()
    {
        //write your code here
    }

    public void add(Graphics g)
    {
        //do nothing
    }

    public void remove(Graphics g)
    {
        //do nothing
    }

    public Graphics getChild(int i)
    {
        return null;
    }
}

