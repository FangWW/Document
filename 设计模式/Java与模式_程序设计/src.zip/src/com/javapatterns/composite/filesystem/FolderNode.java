package com.javapatterns.composite.filesystem;

public class FolderNode extends FileSystemNode
{
    public FolderNode() {
    }

    public int getSize()
    {
        return 0;
    }
}
