package com.javapatterns.doubledispatch.ballkicking1;

abstract public class West 
{
	public abstract void goWest1(SubEast1 east);
	public abstract void goWest2(SubEast2 east);
}
